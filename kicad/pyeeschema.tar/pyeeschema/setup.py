from distutils.core import setup
import os.path

setup(
    name='eeschema',
    version='0.1.0',
    description="KiCad's eeschema file format API.",
    author='Roman Pavelka',
    author_email='chaoticroman@seznam.cz',
    url='http://romanpavelka.cz/',

    packages=['eeschema'],
    license='GNU General Public License v3 (GPLv3)',
#    long_description=open('README.txt').read(),
#    scripts=[os.path.join('bin','cdf2mat.py')],
    )
